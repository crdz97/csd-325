def get_formatted_capital(capital, country, population='', language=''):
    capital_country = f"{capital}, {country}"
    """Generate a neatly formatted capital and country name."""
    if population.strip():
        capital_country += f" - Population {population}"
    if language.strip():
        capital_country += f" - Language {language}"
    return capital_country.title()