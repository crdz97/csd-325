from country_functions import get_formatted_capital

def test_capital_country_name():
      """Do names like 'Beijing, China - Population 520, Mandarin' work?"""
      formatted_name = get_formatted_capital('beijing', 'china', '520', 'mandarin')
      assert formatted_name == 'Beijing, China - Population 520, Mandarin'
