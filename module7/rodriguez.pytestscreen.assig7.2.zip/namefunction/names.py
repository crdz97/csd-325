from country_functions import get_formatted_capital

print("Enter 'q' at any time to quit.")
while True:
    capital = input("\nPlease give me a capital city: ")
    if capital == 'q':
        break
    country = input("Please give me a country: ")
    if country == 'q':
        break
    population = input("Please give me the population: ")
    if population == 'q':
        break       
    language = input("Please give me the primary language: ")
    if language == 'q':
        break

    formatted_name = get_formatted_capital(capital, country, population, language)
    print(f"\tNeatly formatted name: {formatted_name}")